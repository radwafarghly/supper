<!DOCTYPE html>
<html lang="ar" dir="rtl" >
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <!--===============================================================================================-->
    <link rel="icon" type="image/png" href="<?php echo e(asset('images/icons/favicon.ico')); ?>"/>
    <!--===============================================================================================-->
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>">
    <!--===============================================================================================-->
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('fonts/font-awesome-4.7.0/css/font-awesome.min.css')); ?>">
    <!--===============================================================================================-->
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('fonts/Linearicons-Free-v1.0.0/icon-font.min.css')); ?>">
    <!--===============================================================================================-->
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/animate/animate.css')); ?>">
    <!--===============================================================================================-->
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/css-hamburgers/hamburgers.min.css')); ?>">
    <!--===============================================================================================-->
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/animsition/css/animsition.min.css')); ?>">
    <!--===============================================================================================-->
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/select2/select2.min.css')); ?>">
    <!--===============================================================================================-->
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/daterangepicker/daterangepicker.css')); ?>">
    <!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/util.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/main.css')); ?>">
<link href="https://fonts.googleapis.com/css?family=Cairo" rel="stylesheet">
</head>
<body style="background-color: #666666;">



            <?php echo $__env->yieldContent('content'); ?>




    <!-- JS -->

    <!--===============================================================================================-->
        <script src="<?php echo e(asset('vendor/jquery/jquery-3.2.1.min.js')); ?>"></script>
    <!--===============================================================================================-->
        <script src="<?php echo e(asset('vendor/animsition/js/animsition.min.js')); ?>"></script>
    <!--===============================================================================================-->
        <script src="<?php echo e(asset('vendor/bootstrap/js/popper.js')); ?>"></script>
        <script src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
    <!--===============================================================================================-->
        <script src="<?php echo e(asset('vendor/select2/select2.min.js')); ?>"></script>
    <!--===============================================================================================-->
        <script src="<?php echo e(asset('vendor/daterangepicker/moment.min.js')); ?>"></script>
        <script src="<?php echo e(asset('vendor/daterangepicker/daterangepicker.js')); ?>"></script>
    <!--===============================================================================================-->
        <script src="<?php echo e(asset('vendor/countdowntime/countdowntime.js')); ?>"></script>
    <!--===============================================================================================-->
        <script src="<?php echo e(asset('js/main.js')); ?>"></script>
                    <?php echo $__env->yieldContent('script'); ?>

        <script>
            $(".selection-2").select2({
            // minimumResultsForSearch: 20,
            dropdownParent: $('#dropDownSelect2')
        });</script>
</body>
</html>
