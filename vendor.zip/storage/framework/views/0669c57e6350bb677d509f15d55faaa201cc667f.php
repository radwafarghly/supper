<?php $__env->startSection('content'); ?>

<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
            <div class="login100-more" style="background-image: url('images/loginphoto.jpg');">
				</div>
				<form class="login100-form validate-form"  method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>

					<span class="login100-form-title p-b-43">
                       <?php echo e(__('auth.login')); ?>

                    </span>

					<div class="wrap-input100 validate-input" data-validate = "Valid email is required: ex@abc.xyz">
						<input class="input100" type="email" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
						<span class="focus-input100"></span>
                        <span class="label-input100"><?php echo e(__('auth.email-address')); ?></span>
                    </div>
                        <?php if($errors->has('email')): ?>
                            <strong class="worng"><?php echo e($errors->first('email')); ?></strong>
                        <?php endif; ?>
					<div class="wrap-input100 validate-input" data-validate="Password is required">
						<input class="input100" type="password" name="password" required>
						<span class="focus-input100"></span>
                        <span class="label-input100"><?php echo e(__('auth.password')); ?></span>

                    </div>
                       <?php if($errors->has('password')): ?>
                        <strong class="worng"><?php echo e($errors->first('password')); ?></strong>
                       <?php endif; ?>

					<div class="flex-sb-m w-full p-t-3 p-b-32">
						<div class="contact100-form-checkbox">
							<input class="input-checkbox100" id="ckb1" type="checkbox" name="remember-me">
							<label class="label-checkbox100" for="ckb1">
                            <?php echo e(__('auth.rememberme')); ?>

							</label>
						</div>
						<div>
							<a href="<?php echo e(route('password.request')); ?>" class="txt1">
                            <?php echo e(__('auth.forgot-password')); ?>

							</a>
						</div>
					</div>
					<div class="container-login100-form-btn">
						<button class="login100-form-btn" type="submit" name="signin">
                        <?php echo e(__('auth.login')); ?>

						</button>
					</div>
					<div class="text-center p-t-46 p-b-20">
						<span class="txt1">
                        <a href="<?php echo e(route('register')); ?>"><?php echo e(__('auth.create-account')); ?></a>
						</span>
					</div>
				</form>
			</div>
		</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>