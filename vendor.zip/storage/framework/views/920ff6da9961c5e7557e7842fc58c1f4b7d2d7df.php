<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    You are logged in!
                </div>
            </div>
        </div>
    </div>
</div>

<ul class="list-inline">
        <?php $__currentLoopData = $user->getMedia($user->galleryMediaCollection); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="gallery-item text-center list-inline-item" style="width: 48%">
                <?php if($media->getCustomProperty('featured', false)): ?>
                    <span class="featured-item"><i class="fa fa-fw fa-2x fa-star"></i></span>
                <?php endif; ?>
                <a href="<?php echo e($media->getUrl()); ?>" data-lightbox="user-gallery">
                    <img src="<?php echo e($media->getUrl()); ?>" class="img-responsive" alt="user Gallery Image"/></a>
                    <div class="item-buttons" style="display: none;">
                        <a href=""
                           class="btn btn-sm btn-danger item-button" title="Delete Gallery Item"
                           data-action="delete" data-page_action="reloadGallery">
                            <i class="fa fa-fw fa-remove"></i>
                        </a>
                        <?php if(!$media->getCustomProperty('featured', false)): ?>
                            <a href="{"
                               class="btn btn-sm btn-warning item-button"
                               title="Mark as Featured" data-action="post" data-page_action="reloadGallery">
                                <i class="fa fa-fw fa-star"></i>
                            </a>
                        <?php endif; ?>
                    </div>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>


 

<form action="<?php echo e(route("gallery.upload")); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>

    

    <div class="form-group">
        <label for="document">image</label>
        <div class="needsclick dropzone" id="document-dropzone">
        </div>
    </div>
</form>

<script>
  var uploadedDocumentMap = {}
  Dropzone.options.documentDropzone = {
    url: '<?php echo e(route('gallery.upload')); ?>',
    maxFilesize: 2, // MB
    acceptedFiles: 'image/*',
    dictDefaultMessage:'<button type="button" class="btn btn-default">Basic</button>',
    headers: {
      'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
    },
    addRemoveLinks:false,
    success: function(file, response)
    {
        console.log(response);
        $('#document-dropzone').html('<button type="button" class="btn btn-default">Basic</button>');
    },
  }
</script>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>